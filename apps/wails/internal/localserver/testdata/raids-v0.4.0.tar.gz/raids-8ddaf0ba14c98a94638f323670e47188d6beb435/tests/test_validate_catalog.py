from __future__ import annotations

import tempfile
import textwrap
import unittest
from pathlib import Path

from scripts.validate_catalog import (
    PUBLIC_DEFAULT_TOKEN,
    CatalogValidationError,
    validate_catalog,
)

PROFILE = """
apiVersion: gizclaw.admin/v1alpha1
kind: RuntimeProfile
metadata:
  id: default
spec:
  workflows:
    system:
      friend_chatroom: chatroom
      group_chatroom: chatroom
      pet: pet-care
    collections: {}
  resources:
    models:
      asr:
        resource_id: asr-model
        i18n:
          en: {display_name: ASR}
          zh-CN: {display_name: 语音识别}
    memories:
      pet-care:
        layout_id: pet-care
        driver: flowcraft
        connection:
          type: flowcraft_bbh
"""

TOKEN = f"""
apiVersion: gizclaw.admin/v1alpha1
kind: RegistrationToken
metadata:
  id: default-runtime
spec:
  token: {PUBLIC_DEFAULT_TOKEN}
  runtime_profile_id: default
"""

CHATROOM = """
apiVersion: gizclaw.admin/v1alpha1
kind: Workflow
metadata:
  id: chatroom
spec:
  driver: chatroom
  chatroom:
    transcript:
      enabled: true
      asr_model: asr
"""

PET = """
apiVersion: gizclaw.admin/v1alpha1
kind: Workflow
metadata:
  id: pet-care
spec:
  driver: pet
  memory: pet-care
  pet: {}
"""

MEMORY_LAYOUT = """
apiVersion: gizclaw.admin/v1alpha1
kind: MemoryLayout
metadata:
  id: pet-care
spec:
  flowcraft:
    extraction:
      model: asr
      mode: single_pass
    bbh: {}
    lanes:
      - name: pet-care
        kind: note
        description: Durable pet facts.
        extract: Extract durable pet facts.
        recall: Use relevant pet facts.
    write:
      mode: sync
      tier: general
  mem0:
    custom_instructions: Keep durable pet facts.
    custom_categories:
      pet-care: Durable pet facts.
  volc_mem0:
    strategies:
      - {name: pet-care, type: semantic, custom_instructions: Keep durable pet facts.}
"""

MODEL = """
apiVersion: gizclaw.admin/v1alpha1
kind: Model
metadata:
  id: asr-model
spec:
  kind: asr
  source: manual
  provider:
    kind: openai-tenant
    id: openai
  display_name: ASR Model
  provider_data: {}
"""

CREDENTIAL = """
apiVersion: gizclaw.admin/v1alpha1
kind: Credential
metadata:
  id: credential
spec:
  provider: openai
  body: {api_key: test}
"""

TENANT = """
apiVersion: gizclaw.admin/v1alpha1
kind: OpenAITenant
metadata:
  id: openai
spec:
  kind: compatible
  credential_id: credential
  base_url: https://example.com/v1
  api_mode: chat_completions
"""

VOICE = """
apiVersion: gizclaw.admin/v1alpha1
kind: Voice
metadata:
  id: voice
spec:
  source: manual
  provider:
    kind: openai-tenant
    id: openai
  display_name: Test Voice
  provider_data: {}
"""

EXAMPLE = """
apiVersion: gizclaw.admin/v1alpha1
kind: RuntimeProfile
metadata:
  id: raids
spec: {}
"""


class CatalogValidationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.write("runtime-profiles/default.yaml", PROFILE)
        self.write("runtime-profile.example.yaml", EXAMPLE)
        self.write("registration-tokens/default.yaml", TOKEN)
        self.write("workflows/chatroom/social.yaml", CHATROOM)
        self.write("workflows/pet/pet-care.yaml", PET)
        self.write("memory-layouts/pet-care.yaml", MEMORY_LAYOUT)
        self.write("credentials/credential.yaml", CREDENTIAL)
        self.write("tenants/openai.yaml", TENANT)
        self.write("models/asr-model.yaml", MODEL)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def write(self, relative: str, contents: str) -> None:
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(textwrap.dedent(contents).lstrip(), encoding="utf-8")

    def assert_invalid(self, expected: str) -> None:
        with self.assertRaises(CatalogValidationError) as raised:
            validate_catalog(self.root)
        self.assertIn(expected, "\n".join(raised.exception.errors))

    def test_accepts_complete_default_bootstrap_closure(self) -> None:
        validate_catalog(self.root)

    def test_public_default_token_uuidv5_derivation_is_stable(self) -> None:
        self.assertEqual(
            PUBLIC_DEFAULT_TOKEN,
            "28c4e4e9-a05f-5a7e-815e-9cf9afb6878f",
        )

    def test_rejects_missing_resource_reference(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("id: asr-model", "id: another-model"),
        )
        self.assert_invalid("references missing Model/asr-model")

    def test_rejects_missing_metadata_id(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("  id: asr-model\n", ""),
        )
        self.assert_invalid(
            "models/asr-model.yaml: metadata.id must be a non-empty string"
        )

    def test_rejects_empty_metadata_id(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("  id: asr-model", "  id: ''"),
        )
        self.assert_invalid(
            "models/asr-model.yaml: metadata.id must be a non-empty string"
        )

    def test_rejects_metadata_id_with_surrounding_whitespace(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("  id: asr-model", '  id: " asr-model "'),
        )
        self.assert_invalid("metadata.id must not have surrounding whitespace")

    def test_rejects_metadata_id_over_character_limit(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("  id: asr-model", f"  id: {'a' * 1025}"),
        )
        self.assert_invalid("metadata.id exceeds the 1024-character limit")

    def test_rejects_metadata_id_uri_dot_segments(self) -> None:
        for resource_id in (".", ".."):
            with self.subTest(resource_id=resource_id):
                self.write(
                    "models/asr-model.yaml",
                    MODEL.replace("  id: asr-model", f"  id: {resource_id}"),
                )
                self.assert_invalid("metadata.id must not be a URI dot segment")

    def test_rejects_legacy_metadata_name(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("  id: asr-model", "  id: asr-model\n  name: legacy"),
        )
        self.assert_invalid("models/asr-model.yaml: metadata.name is legacy")

    def test_rejects_environment_dependent_metadata_id(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("  id: asr-model", "  id: ${MODEL_ID}"),
        )
        self.assert_invalid("models/asr-model.yaml: metadata.id must be concrete")

    def test_rejects_environment_dependent_resource_reference(self) -> None:
        self.write(
            "tenants/openai.yaml",
            TENANT.replace(
                "credential_id: credential", "credential_id: ${CREDENTIAL_ID}"
            ),
        )
        self.assert_invalid("credential_id must be a concrete Credential ID")

    def test_rejects_resource_reference_with_surrounding_whitespace(self) -> None:
        self.write(
            "tenants/openai.yaml",
            TENANT.replace(
                "credential_id: credential", 'credential_id: " credential "'
            ),
        )
        self.assert_invalid(
            "credential_id must not have surrounding whitespace in the Credential ID"
        )

    def test_rejects_resource_reference_over_character_limit(self) -> None:
        self.write(
            "tenants/openai.yaml",
            TENANT.replace("credential_id: credential", f"credential_id: {'a' * 1025}"),
        )
        self.assert_invalid("exceeds the 1024-character Credential ID limit")

    def test_rejects_resource_reference_uri_dot_segments(self) -> None:
        for resource_id in (".", ".."):
            with self.subTest(resource_id=resource_id):
                self.write(
                    "tenants/openai.yaml",
                    TENANT.replace(
                        "credential_id: credential", f"credential_id: {resource_id}"
                    ),
                )
                self.assert_invalid("credential_id must not be a URI dot segment")

    def test_rejects_missing_documentation_example(self) -> None:
        (self.root / "runtime-profile.example.yaml").unlink()
        self.assert_invalid("required documentation example is missing")

    def test_rejects_legacy_name_in_documentation_example(self) -> None:
        self.write(
            "runtime-profile.example.yaml",
            """
            apiVersion: gizclaw.admin/v1alpha1
            kind: RuntimeProfile
            metadata:
              name: raids
            spec: {}
            """,
        )
        self.assert_invalid("runtime-profile.example.yaml: metadata.name is legacy")

    def test_rejects_ambiguous_duplicate_resource(self) -> None:
        self.write("models/duplicate.yaml", MODEL)
        self.assert_invalid("ambiguous duplicate Model/asr-model")

    def test_rejects_legacy_tenant_credential_name(self) -> None:
        self.write(
            "tenants/openai.yaml",
            TENANT.replace("credential_id: credential", "credential_name: credential"),
        )
        self.assert_invalid("spec.credential_name is legacy")

    def test_rejects_missing_tenant_credential_reference(self) -> None:
        self.write(
            "tenants/openai.yaml",
            TENANT.replace("credential_id: credential", "credential_id: missing"),
        )
        self.assert_invalid("references missing Credential/missing")

    def test_rejects_wrong_kind_tenant_credential_reference(self) -> None:
        self.write(
            "tenants/openai.yaml",
            TENANT.replace("credential_id: credential", "credential_id: asr-model"),
        )
        self.assert_invalid(
            "references Credential/asr-model, but asr-model is defined as Model"
        )

    def test_rejects_empty_tenant_credential_reference(self) -> None:
        self.write(
            "tenants/openai.yaml",
            TENANT.replace("credential_id: credential", "credential_id: ''"),
        )
        self.assert_invalid("credential_id must be a non-empty Credential ID")

    def test_rejects_legacy_model_provider_name(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("    id: openai", "    name: openai"),
        )
        self.assert_invalid("spec.provider.name is legacy")

    def test_rejects_legacy_model_display_name(self) -> None:
        self.write(
            "models/asr-model.yaml",
            MODEL.replace("  display_name: ASR Model", "  name: ASR Model"),
        )
        self.assert_invalid("Model/asr-model.spec.name is legacy")

    def test_rejects_legacy_voice_fields(self) -> None:
        self.write(
            "voices/openai/voice.yaml",
            VOICE.replace("    id: openai", "    name: openai").replace(
                "  display_name: Test Voice", "  name: Test Voice"
            ),
        )
        self.assert_invalid("Voice/voice.spec.provider.name is legacy")
        self.assert_invalid("Voice/voice.spec.name is legacy")

    def test_rejects_unbound_workflow_alias(self) -> None:
        self.write(
            "workflows/chatroom/social.yaml",
            CHATROOM.replace("asr_model: asr", "asr_model: missing"),
        )
        self.assert_invalid("required models alias 'missing' is not bound")

    def test_rejects_missing_memory_layout(self) -> None:
        self.write(
            "memory-layouts/pet-care.yaml",
            MEMORY_LAYOUT.replace("id: pet-care", "id: another-layout"),
        )
        self.assert_invalid(
            "references MemoryLayout/pet-care, but pet-care is defined as Workflow"
        )

    def test_rejects_unbound_workflow_memory_alias(self) -> None:
        self.write(
            "workflows/pet/pet-care.yaml",
            PET.replace("memory: pet-care", "memory: missing"),
        )
        self.assert_invalid(
            "memory alias 'missing' is not bound by RuntimeProfile/default"
        )

    def test_rejects_memory_layout_id_that_does_not_match_alias(self) -> None:
        self.write(
            "runtime-profiles/default.yaml",
            PROFILE.replace("layout_id: pet-care", "layout_id: another-layout"),
        )
        self.assert_invalid("layout_id must match its stable memory alias 'pet-care'")

    def test_rejects_wrong_scenario_memory_alias(self) -> None:
        self.write(
            "workflows/pet/pet-care.yaml",
            PET.replace("memory: pet-care", "memory: another-memory"),
        )
        self.write(
            "runtime-profiles/default.yaml",
            PROFILE.replace(
                "pet-care:\n        layout_id: pet-care",
                "another-memory:\n        layout_id: pet-care",
            ),
        )
        self.assert_invalid("Workflow/pet-care.spec.memory must be 'pet-care'")

    def test_rejects_incompatible_memory_driver_and_connection(self) -> None:
        self.write(
            "runtime-profiles/default.yaml",
            PROFILE.replace("driver: flowcraft", "driver: mem0"),
        )
        self.assert_invalid("driver 'mem0' cannot use connection type 'flowcraft_bbh'")

    def test_rejects_unbound_memory_layout_model_alias(self) -> None:
        self.write(
            "memory-layouts/pet-care.yaml",
            MEMORY_LAYOUT.replace("model: asr", "model: missing"),
        )
        self.assert_invalid(
            "MemoryLayout/pet-care: required models alias 'missing' is not bound"
        )

    def test_rejects_memory_layout_without_lane_guidance(self) -> None:
        self.write(
            "memory-layouts/pet-care.yaml",
            MEMORY_LAYOUT.replace(
                "        extract: Extract durable pet facts.",
                "        extract: ''",
            ),
        )
        self.assert_invalid(
            "MemoryLayout/pet-care.spec.flowcraft.lanes.0.extract "
            "must be a non-empty string"
        )

    def test_rejects_memory_layout_with_incomplete_mem0_categories(self) -> None:
        self.write(
            "memory-layouts/pet-care.yaml",
            MEMORY_LAYOUT.replace(
                "    custom_categories:\n      pet-care: Durable pet facts.",
                "    custom_categories: {}",
            ),
        )
        self.assert_invalid(
            "Mem0 categories must exactly match Flowcraft lanes: missing pet-care"
        )

    def test_rejects_memory_layout_with_incomplete_volc_strategy(self) -> None:
        self.write(
            "memory-layouts/pet-care.yaml",
            MEMORY_LAYOUT.replace(
                "custom_instructions: Keep durable pet facts.}",
                "custom_instructions: ''}",
            ),
        )
        self.assert_invalid(
            "MemoryLayout/pet-care.spec.volc_mem0.strategies.0"
            ".custom_instructions must be a non-empty string"
        )

    def test_rejects_legacy_nested_flowcraft_memory(self) -> None:
        self.write(
            "workflows/pet/pet-care.yaml",
            """
            apiVersion: gizclaw.admin/v1alpha1
            kind: Workflow
            metadata:
              id: pet-care
            spec:
              driver: pet
              memory: pet-care
              pet:
                driver: flowcraft
                flowcraft:
                  agent:
                    graph: {}
                  memory: {}
            """,
        )
        with self.assertRaises(CatalogValidationError) as raised:
            validate_catalog(self.root)
        errors = "\n".join(raised.exception.errors)
        self.assertIn("spec.pet.flowcraft.agent is legacy", errors)
        self.assertIn("spec.pet.flowcraft.memory is legacy", errors)

    def test_rejects_memory_graph_without_outer_alias(self) -> None:
        self.write(
            "workflows/pet/pet-care.yaml",
            """
            apiVersion: gizclaw.admin/v1alpha1
            kind: Workflow
            metadata:
              id: pet-care
            spec:
              driver: pet
              pet:
                driver: flowcraft
                flowcraft:
                  graph:
                    name: pet
                    entry: recall
                    nodes:
                      - id: recall
                        type: memory_recall
                        config:
                          query: {text_from: input}
                          output: memory
                          top_k: 1
                    edges:
                      - {from: recall, to: __end__}
            """,
        )
        self.assert_invalid(
            "uses memory graph nodes and must declare outer spec.memory"
        )

    def test_rejects_external_fields_in_public_memory_connection(self) -> None:
        self.write(
            "runtime-profiles/default.yaml",
            PROFILE.replace(
                "type: flowcraft_bbh",
                "type: flowcraft_bbh\n          directory: /tmp/memory",
            ),
        )
        self.assert_invalid("connection has unsupported fields: directory")

    def test_rejects_duplicate_token_value(self) -> None:
        self.write(
            "registration-tokens/other.yaml",
            TOKEN.replace("id: default-runtime", "id: other"),
        )
        self.assert_invalid("token value duplicates RegistrationToken/default-runtime")

    def test_rejects_duplicate_normalized_token_value(self) -> None:
        for case, token in {
            "ascii": f" {PUBLIC_DEFAULT_TOKEN} ",
            "unicode": f"\u00a0{PUBLIC_DEFAULT_TOKEN}\u00a0",
        }.items():
            with self.subTest(case=case):
                self.write(
                    "registration-tokens/other.yaml",
                    TOKEN.replace("id: default-runtime", "id: other").replace(
                        f"token: {PUBLIC_DEFAULT_TOKEN}", f'token: "{token}"'
                    ),
                )
                self.assert_invalid(
                    "token value duplicates RegistrationToken/default-runtime"
                )

    def test_rejects_missing_empty_or_non_string_token(self) -> None:
        cases = {
            "missing": "",
            "empty": '  token: "   "\n',
            "non-string": "  token: 123\n",
        }
        for case, token_line in cases.items():
            with self.subTest(case=case):
                other = TOKEN.replace("id: default-runtime", "id: other").replace(
                    f"  token: {PUBLIC_DEFAULT_TOKEN}\n", token_line
                )
                self.write("registration-tokens/other.yaml", other)
                self.assert_invalid(
                    "RegistrationToken/other.spec.token must be a non-empty string"
                )

    def test_rejects_registration_token_with_missing_profile(self) -> None:
        self.write(
            "registration-tokens/other.yaml",
            TOKEN.replace("id: default-runtime", "id: other")
            .replace(f"token: {PUBLIC_DEFAULT_TOKEN}", "token: other")
            .replace("runtime_profile_id: default", "runtime_profile_id: missing"),
        )
        self.assert_invalid(
            "RegistrationToken/other.spec.runtime_profile_id references "
            "missing RuntimeProfile/missing"
        )

    def test_rejects_legacy_registration_token_profile_name(self) -> None:
        self.write(
            "registration-tokens/default.yaml",
            TOKEN.replace(
                "runtime_profile_id: default", "runtime_profile_name: default"
            ),
        )
        self.assert_invalid("spec.runtime_profile_name is legacy")

    def test_rejects_placeholder_in_default_profile(self) -> None:
        self.write(
            "runtime-profiles/default.yaml",
            PROFILE.replace("resource_id: asr-model", "resource_id: <model-id>"),
        )
        self.assert_invalid("unresolved placeholder")

    def test_rejects_public_default_firmware_binding(self) -> None:
        self.write(
            "registration-tokens/default.yaml",
            TOKEN + "  firmware_id: h106\n",
        )
        self.assert_invalid("prohibited default field spec.firmware_id")


if __name__ == "__main__":
    unittest.main()
